package com.healthcare.service;

import java.util.List;

import com.healthcare.dao.PatientDao;
import com.healthcare.entity.Patient;

public class PatientService {
 PatientDao pd=new PatientDao();
 public String storePatient(Patient patient) {
		if(pd.storePatient(patient)>0){
			return "patients details stored successfully";
		
		}else {
			return "Patients details didint stored";
		}
 }
 public List<Patient> findAllPatients() {
	return pd.findAllPatients();
	}
}
