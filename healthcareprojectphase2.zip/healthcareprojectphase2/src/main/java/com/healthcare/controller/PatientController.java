package com.healthcare.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.healthcare.entity.Patient;
import com.healthcare.service.PatientService;
/**
 * Servlet implementation class PatientController
 */
@WebServlet("/PatientController")
public class PatientController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PatientController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		PatientService ps=new PatientService();
		List<Patient> listOfPatient=ps.findAllPatients();
		response.sendRedirect("displayPatients.jsp");
		HttpSession hs = request.getSession();
		hs.setAttribute("patients", listOfPatient);
		response.setContentType("text/html");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		String pname=request.getParameter("pname");
		String pemail=request.getParameter("pemail");
		String pno=request.getParameter("pno");
		float age=Float.parseFloat(request.getParameter("age"));
		String pdiagnosis=request.getParameter("pdiagnosis");
		String remarks=request.getParameter("remarks");
		String gender=request.getParameter("gender");
		Patient p=new Patient();
		p.setPname(pname);
		p.setPemail(pemail);
		p.setPno(pno);
		p.setAge(age);
		p.setPdiagnosis(pdiagnosis);
		p.setRemarks(remarks);
		p.setGender(gender);
		
		PatientService ps=new PatientService();
		String result=ps.storePatient(p);
		
		pw.print(result);
		RequestDispatcher rd = request.getRequestDispatcher("PatientForm.jsp");
		rd.include(request, response);
		response.setContentType("text/html");
	}

}
