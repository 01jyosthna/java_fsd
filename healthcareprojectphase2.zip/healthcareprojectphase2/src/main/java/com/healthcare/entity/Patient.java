package com.healthcare.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Patient {
	
	@Id
	@GeneratedValue (strategy=GenerationType.IDENTITY)
	private int pid;
	private String pname;
	private String pemail;
	private String pno;
	private float age;
	private String pdiagnosis;
	private String remarks;
	private String gender;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPemail() {
		return pemail;
	}
	public void setPemail(String pemail) {
		this.pemail = pemail;
	}
	public String getPno() {
		return pno;
	}
	public void setPno(String pno) {
		this.pno = pno;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	public String getPdiagnosis() {
		return pdiagnosis;
	}
	public void setPdiagnosis(String pdiagnosis) {
		this.pdiagnosis = pdiagnosis;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Patient(int pid, String pname, String pemail, String pno, float age, String pdiagnosis, String remarks,
			String gender) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pemail = pemail;
		this.pno = pno;
		this.age = age;
		this.pdiagnosis = pdiagnosis;
		this.remarks = remarks;
		this.gender = gender;
	}
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}
	
		
	}
	